import numpy as np
import matplotlib.pyplot as plt
import pandas as pd



auxy = ["BCA","BHV","CDA","CHA","FGA","FGT","FSS","GHP","GIB","GRL","HAD","LCB","MPA","MSW","NDA","NXA","OZD","PAR","PBD","PMD","RMS","SDA","SHI","SNM","SPI","TBG","TBN","TCL","USD","UWD","WTL","WWT"]
data = [0 for i in range(len(auxy))]                                                               
for i in range(len(auxy)):
  data[i] = pd.read_csv("C:/Users/User/OneDrive - Universidad de Guanajuato/2 SEMESTRE/HGI/PROYECTO_2/DATA_INDEX/2020-epi-indicators-time-series-na-csv/2020-epi-indicators-time-series-na/"+str(auxy[i])+"_ind_na.csv",skiprows = 126 ,usecols= [3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28],nrows=(1))
colnam = ["1995","1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018","2019","2020"]
for i in range(len(auxy)): data[i].columns = colnam
for i in range(len(auxy)): 
     data[i] = pd.DataFrame(data[i]) 
     data[i] = data[i].transpose()
     
     
     
     
for i in range(len(auxy)):
    data[i]=data[i].reset_index(drop=True)
    data[i].columns = ["Valor"]

    
for i in range(len(auxy)):
    data[i].insert(0, "Año", colnam, allow_duplicates=False) 


Etiquet = auxy.copy()
Dat = auxy
for i in range(len(Etiquet)):
     globals()[str(Etiquet[i])]= data[i].fillna(0)


#"""ENVIROMENTAL PERFORMANCE"""
#EP = [HLT, ECO]

path_1="C:/Users/User/OneDrive - Universidad de Guanajuato/2 SEMESTRE/HGI/PROYECTO_2/CODIGO/EP2_1995_2020/"


for i in range(len(Etiquet)):
    datos = data[i]
    plt.rcParams['figure.figsize'] = (13.67,6.71)
    plt.plot(datos["Año"], datos["Valor"], marker = ".", color="green",linewidth=2, label = str(Etiquet[i]))
    plt.legend(fontsize=14)
    plt.title("".join(("Indice "+str(Etiquet[i])+" medio (1995-2020) en México")),loc='center',fontsize=16)
    plt.ylim(0,105)
    plt.yticks([0,10,20,30,40,50,60,70,80,90,100])
    plt.xlim(np.amin(datos["Año"]),np.amax(datos["Año"]))
    plt.xlabel('Años',fontsize=14)
    plt.ylabel('(%)',fontsize=14)
    plt.grid()
    #plt.savefig((path_1+str(Etiquet[i])+"_1995_2020.png"), dpi=300)
    plt.clf()

"""PARA CADA AÑO VERMOS EL DESEMPEÑO DEL AMBIENTE EN MEXICO"""

"""HLT"""
PMD["Valor"]= PMD["Valor"]*0.55 
HAD["Valor"]= HAD["Valor"]*0.4 
OZD["Valor"]= OZD["Valor"]*0.05 
AIR= pd.DataFrame()
AIR["Año"]=colnam
for i in range(25):
    AIR["Valor"]=(PMD["Valor"]+HAD["Valor"]+OZD["Valor"])

USD["Valor"]= USD["Valor"]*0.4 
UWD["Valor"]= UWD["Valor"]*0.60
H2O= pd.DataFrame()
H2O["Año"]=colnam
for i in range(25):
    H2O["Valor"]=(USD["Valor"]+UWD["Valor"])

HMT=pd.DataFrame()
HMT["Año"]=colnam
HMT["Valor"]=PBD["Valor"]

WMG=pd.DataFrame()
WMG["Año"]=colnam
WMG["Valor"]=MSW["Valor"]

path_HLT="C:/Users/User/OneDrive - Universidad de Guanajuato/2 SEMESTRE/HGI/PROYECTO_2/CODIGO/EP2_1995_2020/HLT/"
datos = WMG
plt.rcParams['figure.figsize'] = (13.67,6.71)
plt.plot(datos["Año"], datos["Valor"], marker = ".", color="blue",linewidth=2, label = "WMG" )
plt.legend(fontsize=14)
plt.title("".join(("Indice WMG medio (1995-2020) en México")),loc='center',fontsize=16)
plt.ylim(0,105)
plt.yticks([0,10,20,30,40,50,60,70,80,90,100])
plt.xlim(np.amin(datos["Año"]),np.amax(datos["Año"]))
plt.xlabel('Años',fontsize=14)
plt.ylabel('(%)',fontsize=14)
plt.grid()
#plt.savefig((path_HLT+"WMG/WMG_1995_2020.png"), dpi=300)
plt.clf()


HLT=pd.DataFrame()
HLT["Año"]=colnam
AIR["Valor"] = AIR["Valor"]*0.5
H2O["Valor"] = H2O["Valor"]*0.4
HMT["Valor"] = HMT["Valor"]*0.05
WMG["Valor"] = WMG["Valor"]*0.05

HLT["Valor"]=(AIR["Valor"]+H2O["Valor"]+HMT["Valor"]+WMG["Valor"])
datos = HLT
plt.rcParams['figure.figsize'] = (13.67,6.71)
plt.plot(datos["Año"], datos["Valor"], marker = ".", color="darkviolet",linewidth=2, label = "HLT" )
plt.legend(fontsize=14)
plt.title("".join(("Indice HLT medio (1995-2020) en México")),loc='center',fontsize=16)
plt.ylim(0,105)
plt.yticks([0,10,20,30,40,50,60,70,80,90,100])
plt.xlim(np.amin(datos["Año"]),np.amax(datos["Año"]))
plt.xlabel('Años',fontsize=14)
plt.ylabel('(%)',fontsize=14)
plt.grid()
#plt.savefig((path_HLT+"/HLT_1995_2020.png"), dpi=300)
plt.clf()

"""ECO"""


BDH=pd.DataFrame()
BDH["Año"]=colnam
TBN["Valor"] = TBN["Valor"]*0.2
TBG["Valor"] = TBG["Valor"]*0.2
MPA["Valor"] = MPA["Valor"]*0.2
PAR["Valor"] = PAR["Valor"]*0.1
SHI["Valor"] = SHI["Valor"]*0.1
SPI["Valor"] = SPI["Valor"]*0.1
BHV["Valor"] = BHV["Valor"]*0.1
BDH["Valor"]=(TBN["Valor"]+TBG["Valor"]+MPA["Valor"]+PAR["Valor"]+SHI["Valor"]+SPI["Valor"]+BHV["Valor"])

ECS=pd.DataFrame()
ECS["Año"]=colnam
TCL["Valor"] = TCL["Valor"]*0.9
GRL["Valor"] = GRL["Valor"]*0.05
WTL["Valor"] = WTL["Valor"]*0.05
ECS["Valor"]=(TCL["Valor"]+GRL["Valor"]+WTL["Valor"])

FSH=pd.DataFrame()
FSH["Año"]=colnam
FSS["Valor"] = FSS["Valor"]*0.35
RMS["Valor"] = RMS["Valor"]*0.35
FGT["Valor"] = FGT["Valor"]*0.3
FSH["Valor"]=(FSS["Valor"]+RMS["Valor"]+FGT["Valor"])

CCH=pd.DataFrame()
CCH["Año"]=colnam
CDA["Valor"] = CDA["Valor"]*0.55
CHA["Valor"] = CHA["Valor"]*0.15
FGA["Valor"] = FGA["Valor"]*0.1
NDA["Valor"] = NDA["Valor"]*0.05
BCA["Valor"] = BCA["Valor"]*0.05
LCB["Valor"] = LCB["Valor"]*0.025
GIB["Valor"] = GIB["Valor"]*0.05
GHP["Valor"] = GHP["Valor"]*0.025
CCH["Valor"]=(CDA["Valor"]+CHA["Valor"]+FGA["Valor"]+NDA["Valor"]+BCA["Valor"]+LCB["Valor"]+GIB["Valor"]+GHP["Valor"])

APE=pd.DataFrame()
APE["Año"]=colnam
SDA["Valor"] = SDA["Valor"]*0.5
NXA["Valor"] = NXA["Valor"]*0.5
APE["Valor"]=(SDA["Valor"]+NXA["Valor"])

AGR=pd.DataFrame()
AGR["Año"]=colnam
AGR["Valor"] = SNM["Valor"]

WRS=pd.DataFrame()
WRS["Año"]=colnam
WRS["Valor"] = WWT["Valor"]


path_ECO="C:/Users/User/OneDrive - Universidad de Guanajuato/2 SEMESTRE/HGI/PROYECTO_2/CODIGO/EP2_1995_2020/ECO/"
datos = BDH
plt.rcParams['figure.figsize'] = (13.67,6.71)
plt.plot(datos["Año"], datos["Valor"], marker = ".", color="blue",linewidth=2, label = "BDH" )
plt.legend(fontsize=14)
plt.title("".join(("Indice BDH medio (1995-2020) en México")),loc='center',fontsize=16)
plt.ylim(0,105)
plt.yticks([0,10,20,30,40,50,60,70,80,90,100])
plt.xlim(np.amin(datos["Año"]),np.amax(datos["Año"]))
plt.xlabel('Años',fontsize=14)
plt.ylabel('(%)',fontsize=14)
plt.grid()
#plt.savefig((path_ECO+"BDH/BDH_1995_2020.png"), dpi=300)
plt.clf()

ECO=pd.DataFrame()
ECO["Año"]=colnam
BDH["Valor"] = BDH["Valor"]*0.25
ECS["Valor"] = ECS["Valor"]*0.1
FSH["Valor"] = FSH["Valor"]*0.1
CCH["Valor"] = CCH["Valor"]*0.4
APE["Valor"] = APE["Valor"]*0.05
AGR["Valor"] = AGR["Valor"]*0.05
WRS["Valor"] = WRS["Valor"]*0.05
ECO["Valor"] = (BDH["Valor"]+ECS["Valor"]+FSH["Valor"]+CCH["Valor"]+APE["Valor"]+AGR["Valor"]+WRS["Valor"])


datos = ECO
plt.rcParams['figure.figsize'] = (13.67,6.71)
plt.plot(datos["Año"], datos["Valor"], marker = ".", color="darkviolet",linewidth=2, label = "ECO" )
plt.legend(fontsize=14)
plt.title("".join(("Indice ECO medio (1995-2020) en México")),loc='center',fontsize=16)
plt.ylim(0,105)
plt.yticks([0,10,20,30,40,50,60,70,80,90,100])
plt.xlim(np.amin(datos["Año"]),np.amax(datos["Año"]))
plt.xlabel('Años',fontsize=14)
plt.ylabel('(%)',fontsize=14)
plt.grid()
#plt.savefig((path_ECO+"/ECO_1995_2020.png"), dpi=300)
plt.clf()

"""PERFORMANCE"""
print(ECO)
print(HLT)

PERF = pd.DataFrame()
PERF["Año"]=colnam
HLT["Valor"]=HLT["Valor"]*0.4
ECO["Valor"]=ECO["Valor"]*0.6
PERF["Valor"]=(HLT["Valor"]+ECO["Valor"])

datos = PERF
plt.rcParams['figure.figsize'] = (13.67,6.71)
plt.plot(datos["Año"], datos["Valor"], marker = ".", color="crimson",linewidth=2, label = "EPM" )
plt.legend(fontsize=14)
plt.title("".join(("Indice de Desempeño Ambiental medio (1995-2020) en México (EPM)")),loc='center',fontsize=16.5,fontweight="bold")
plt.ylim(0,105)
plt.yticks([0,10,20,30,40,50,60,70,80,90,100])
plt.xlim(np.amin(datos["Año"]),np.amax(datos["Año"]))
plt.xlabel('Años',fontsize=14)
plt.ylabel('(%)',fontsize=14)
plt.grid()
#plt.savefig((path_1+"/EPI_1995_2020.png"), dpi=300)
plt.clf()

print(PERF)
